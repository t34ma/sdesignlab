program read_binary_records
  implicit none
  integer :: unit, ios, type, length
  integer :: i1, i2, i
  real(4), allocatable :: reals(:)
  character(len=:), allocatable :: str

  unit = 10
  open(unit, file="data.bin", access="stream", form="unformatted", status="old", action="read", iostat=ios)
  if (ios /= 0) then
     print *, "Failed to open file: IOSTAT =", ios
     stop
  end if

  do
     ! Detect end of file
     read(unit, iostat=ios) type
     if (ios /= 0) exit

     read(unit) length

     select case (type)
     case (0)
        allocate(character(len=length) :: str)
        read(unit) str
        print *, "[TYPE 0] String = '" // str // "'"
        deallocate(str)

     case (1)
        allocate(reals(length))
        read(unit) i1
        read(unit) reals
        print *, "[TYPE 1] Integer:", i1
        write(*,'(A)', advance='no') "           Reals:"
        do i = 1, length
           write(*,'(F8.3)', advance='no') reals(i)
        end do
        print *
        deallocate(reals)

     case (2)
        allocate(reals(length))
        read(unit) i1, i2
        read(unit) reals
        print *, "[TYPE 2] Integers:", i1, i2
        write(*,'(A)', advance='no') "           Reals:"
        do i = 1, length
           write(*,'(F8.3)', advance='no') reals(i)
        end do
        print *
        deallocate(reals)

     case default
        print *, "Unknown type:", type
        exit
     end select
  end do

  close(unit)
  print *, "File reading completed."
end program read_binary_records
