#include <stdio.h>
#include <stdlib.h>

void read_type_0(FILE* fp, int length) {
    char* str = (char*) malloc(length + 1);
    if (!str) return;

    fread(str, sizeof(char), length, fp);
    str[length] = '\0';  // null-terminate the string
    printf("[TYPE 0] String: \"%s\"\n", str);
    free(str);
}

void read_type_1(FILE* fp, int length) {
    int i1;
    fread(&i1, sizeof(int), 1, fp);

    float* reals = (float*) malloc(sizeof(float) * length);
    fread(reals, sizeof(float), length, fp);

    printf("[TYPE 1] Integer: %d | Reals:", i1);
    for (int i = 0; i < length; ++i) {
        printf(" %.3f", reals[i]);
    }
    printf("\n");
    free(reals);
}

void read_type_2(FILE* fp, int length) {
    int i1, i2;
    fread(&i1, sizeof(int), 1, fp);
    fread(&i2, sizeof(int), 1, fp);

    float* reals = (float*) malloc(sizeof(float) * length);
    fread(reals, sizeof(float), length, fp);

    printf("[TYPE 2] Integers: %d, %d | Reals:", i1, i2);
    for (int i = 0; i < length; ++i) {
        printf(" %.3f", reals[i]);
    }
    printf("\n");
    free(reals);
}

int main() {
    FILE* fp = fopen("data.bin", "rb");
    if (!fp) {
        perror("Failed to open file");
        return 1;
    }

    int type, length;

    // Read until EOF
    while (fread(&type, sizeof(int), 1, fp) == 1) {
        if (fread(&length, sizeof(int), 1, fp) != 1)
            break;

        switch (type) {
            case 0:
                read_type_0(fp, length);
                break;
            case 1:
                read_type_1(fp, length);
                break;
            case 2:
                read_type_2(fp, length);
                break;
            default:
                printf("Unknown type: %d\n", type);
                fclose(fp);
                return 1;
        }
    }

    fclose(fp);
    return 0;
}
