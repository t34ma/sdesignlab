/******************************************************************************
 * Copyright (c) 1998 Lawrence Livermore National Security, LLC and other
 * HYPRE Project Developers. See the top-level COPYRIGHT file for details.
 *
 * SPDX-License-Identifier: (Apache-2.0 OR MIT)
 ******************************************************************************/

/******************************************************************************
 *
 * Header file for HYPRE library
 *
 *****************************************************************************/

#ifndef HYPRE_HEADER
#define HYPRE_HEADER


/*--------------------------------------------------------------------------
 * Structures
 *--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------
 * Constants
 *--------------------------------------------------------------------------*/

#define HYPRE_UNITIALIZED -999

#define HYPRE_PETSC_MAT_PARILUT_SOLVER 222
#define HYPRE_PARILUT                  333

#define HYPRE_STRUCT  1111
#define HYPRE_SSTRUCT 3333
#define HYPRE_PARCSR  5555

#define HYPRE_ISIS    9911
#define HYPRE_PETSC   9933

#define HYPRE_PFMG    10
#define HYPRE_SMG     11
#define HYPRE_Jacobi  17

#endif
