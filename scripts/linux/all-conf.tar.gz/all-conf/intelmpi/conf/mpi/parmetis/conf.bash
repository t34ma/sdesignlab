patch -p0 < patch3.cmake.int64
make config prefix=${HOME}/lib/parmetis-4.0.3-intelmpi_int64 openmp=1
cd build/Linux-x86_64/
make install
