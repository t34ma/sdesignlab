#!/bin/sh
patch -p0 < patch.scotch613
make scotch ptscotch ptesmumps
#echo please type \'make ptesmumps\' directly on your command line.
