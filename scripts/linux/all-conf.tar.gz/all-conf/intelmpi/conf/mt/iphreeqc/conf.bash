#!/bin/sh
patch -p0 < patch.iphreeqc
./configure --prefix=${HOME}/lib/iphreeqc-3.7.3 CXXFLAGS="-O3 -fPIE" CFLAGS="-O3 -fPIE"
make install
