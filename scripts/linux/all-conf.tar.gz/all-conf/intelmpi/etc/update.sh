#!/bin/sh

SRC=~/work/lib-try/src
DST=~/work/lib/src
#COMMAND=cp
COMMAND="diff -u"

SCOTCH=scotch-v7.0.3
HYPRE=hypre-2.28.0
MUMPS=MUMPS_5.6.0

${COMMAND} ${SRC}/intelmpi/${HYPRE}/src/conf.bash ${DST}/intelmpi/${HYPRE}/src/conf.bash
${COMMAND} ${SRC}/intelmpi_int64/${MUMPS}/Makefile.inc ${DST}/intelmpi_int64/${MUMPS}/Makefile.inc
${COMMAND} ${SRC}/intelmpi_int64/parmetis-4.0.3/conf.bash ${DST}/intelmpi_int64/parmetis-4.0.3/conf.bash
${COMMAND} ${SRC}/intelmpi_int64/${SCOTCH}/src/conf.bash ${DST}/intelmpi_int64/${SCOTCH}/src/conf.bash
${COMMAND} ${SRC}/iphreeqc-3.7.3-15968/conf.bash ${DST}/iphreeqc-3.7.3-15968/conf.bash
${COMMAND} ${SRC}/libseq_int64/${HYPRE}/src/conf.bash ${DST}/libseq_int64/${HYPRE}/src/conf.bash
${COMMAND} ${SRC}/libseq_int64/${MUMPS}/Makefile.inc ${DST}/libseq_int64/${MUMPS}/Makefile.inc

