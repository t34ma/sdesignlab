./configure --prefix=${HOME}/bin/bison
