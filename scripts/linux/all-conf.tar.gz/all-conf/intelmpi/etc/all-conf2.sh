#!/bin/sh

#HOME=${HOME}/DuCOM
HOME=${HOME}/work

ARCH=/home/ducom/mis/arch

SCOTCH=scotch-v7.0.3
HYPRE=hypre-2.28.0
MUMPS=MUMPS_5.6.0

cd ${HOME}/lib

cd src
if [ ! -e intelmpi_int64/ ]; then
  mkdir intelmpi_int64/
fi
if [ ! -e intelmpi/ ]; then
  mkdir intelmpi/
fi
if [ ! -e libseq_int64/ ]; then
  mkdir libseq_int64/
fi
cd ..

tar zxf ${ARCH}/parmetis-4.0.3.tar.gz -C src/intelmpi_int64/
tar zxf ${ARCH}/${SCOTCH}.tar.gz -C src/intelmpi_int64/
tar zxf ${ARCH}/${MUMPS}.tar.gz -C src/intelmpi_int64/
tar zxf ${ARCH}/iphreeqc-3.7.3-15968.tar.gz -C src/
tar zxf ${ARCH}/${HYPRE}.tar.gz -C src/intelmpi
tar zxf ${ARCH}/${MUMPS}.tar.gz -C src/libseq_int64/
tar zxf ${ARCH}/${HYPRE}.tar.gz -C src/libseq_int64/

cp src/conf/mpi/parmetis/* src/intelmpi_int64/parmetis-4.0.3
cp src/conf/mpi/scotch/* src/intelmpi_int64/${SCOTCH}/src
cp src/conf/mpi/hypre/* src/intelmpi/${HYPRE}/src
cp src/conf/mpi/MUMPS/* src/intelmpi_int64/${MUMPS}
cp src/conf/mt/hypre/* src/libseq_int64/${HYPRE}/src
cp src/conf/mt/MUMPS/* src/libseq_int64/${MUMPS}
cp src/conf/mt/iphreeqc/* src/iphreeqc-3.7.3-15968

cd ${HOME}/lib
cd src/intelmpi_int64/parmetis-4.0.3
sh conf.bash

cd ${HOME}/lib
cd src/intelmpi_int64/${SCOTCH}/src
sh conf.bash

cd ${HOME}/lib
cd src/iphreeqc-3.7.3-15968
sh conf.bash

cd ${HOME}/lib
cd src/intelmpi/${HYPRE}/src
HYPRE=${HYPRE} sh conf.bash
make install

cd ${HOME}/lib
ln -sfT parmetis-4.0.3-intelmpi_int64/ parmetis-intelmpi_int64
ln -sfT src/intelmpi_int64/${SCOTCH}/ scotch-intelmpi_int64
ln -sfT iphreeqc-3.7.3/ iphreeqc
ln -sfT ${HYPRE}-intelmpi/ hypre-intelmpi

cd src/intelmpi_int64/${MUMPS}
HOME=${HOME} make

cd ${HOME}/lib
ln -sfT src/intelmpi_int64/${MUMPS}/ MUMPS-intelmpi_int64

cd src/libseq_int64/${HYPRE}/src
HYPRE=${HYPRE} sh conf.bash
make install

cd ${HOME}/lib
cd  src/libseq_int64/${MUMPS}
HOME=${HOME} make

cd ${HOME}/lib
ln -sfT ${HYPRE}-libseq/ hypre-libseq
ln -sfT src/libseq_int64/${MUMPS}/ MUMPS-libseq_int64


### build libraries for ipl64

if [ "$1" != "noilp64" ]; then

  cd ${HOME}/lib

  cd src
  if [ ! -e intelmpi_ilp64/ ]; then
    mkdir intelmpi_ilp64/
  fi
  cd ..

  tar zxf ${ARCH}/${MUMPS}.tar.gz -C src/intelmpi_ilp64/
  tar zxf ${ARCH}/${HYPRE}.tar.gz -C src/intelmpi_int64/

  cp src/conf/mpi64/hypre/* src/intelmpi_int64/${HYPRE}/src
  cp src/conf/mpi64/MUMPS/* src/intelmpi_ilp64/${MUMPS}

  cd ${HOME}/lib
  cd src/intelmpi_int64/${HYPRE}/src
  HYPRE=${HYPRE} sh conf.bash
  make install

  cd ${HOME}/lib
  ln -sfT ${HYPRE}-intelmpi_int64/ hypre-intelmpi_int64

  cd src/intelmpi_ilp64/${MUMPS}
  HOME=${HOME} make

  cd ${HOME}/lib
  ln -sfT src/intelmpi_ilp64/${MUMPS}/ MUMPS-intelmpi_ilp64

fi

