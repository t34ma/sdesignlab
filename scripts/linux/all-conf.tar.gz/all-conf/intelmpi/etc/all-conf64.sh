#!/bin/sh

#HOME=${HOME}/DuCOM
HOME=${HOME}/work

ARCH=/home/ducom/mis/arch

HYPRE=hypre-2.28.0
MUMPS=MUMPS_5.6.0

cd ${HOME}/lib

cd src
mkdir intelmpi_ilp64/
cd ..

tar zxf ${ARCH}/${MUMPS}.tar.gz -C src/intelmpi_ilp64/
tar zxf ${ARCH}/${HYPRE}.tar.gz -C src/intelmpi_int64/

cp src/conf/mpi64/hypre/* src/intelmpi_int64/${HYPRE}/src
cp src/conf/mpi64/MUMPS/* src/intelmpi_ilp64/${MUMPS}

cd ${HOME}/lib
cd src/intelmpi_int64/${HYPRE}/src
HYPRE=${HYPRE} sh conf.bash
make install

cd ${HOME}/lib
ln -sfT ${HYPRE}-intelmpi_int64/ hypre-intelmpi_int64

cd src/intelmpi_ilp64/${MUMPS}
HOME=${HOME} make

cd ${HOME}/lib
ln -sfT src/intelmpi_ilp64/${MUMPS}/ MUMPS-intelmpi_ilp64

