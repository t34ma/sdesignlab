#!/bin/sh

SCOTCH=scotch-v7.0.3
HYPRE=hypre-2.28.0
MUMPS=MUMPS_5.6.0

ln -sfT parmetis-4.0.3-intelmpi_int64/ parmetis-intelmpi_int64
ln -sfT src/intelmpi_int64/${SCOTCH}/ scotch-intelmpi_int64
ln -sfT iphreeqc-3.7.3/ iphreeqc
ln -sfT ${HYPRE}-intelmpi/ hypre-intelmpi
ln -sfT src/intelmpi_int64/${MUMPS}/ MUMPS-intelmpi_int64

#ln -sfT ${HYPRE}-libseq/ hypre-libseq
#ln -sfT src/libseq_int64/${MUMPS}/ MUMPS-libseq_int64

#ln -sfT ${HYPRE}-intelmpi_int64/ hypre-intelmpi_int64
#ln -sfT src/intelmpi_ilp64/${MUMPS}/ MUMPS-intelmpi_ilp64

