#!/bin/sh

#HOME=${HOME}/DuCOM
HOME=${HOME}/work

PLAT=openmpi-gnu
SEQ=libseq-gnu

ARCH=/home/ducom/mis/arch

SCOTCH=scotch-v7.0.3
HYPRE=hypre-2.28.0
MUMPS=MUMPS_5.6.0

cd ${HOME}/lib

cd src
if [ ! -e ${PLAT}_int64/ ]; then
  mkdir ${PLAT}_int64/
fi
if [ ! -e ${PLAT}/ ]; then
  mkdir ${PLAT}/
fi
if [ ! -e ${SEQ}_int64/ ]; then
  mkdir ${SEQ}_int64/
fi
cd ..

tar zxf ${ARCH}/parmetis-4.0.3.tar.gz -C src/${PLAT}_int64/
tar zxf ${ARCH}/${SCOTCH}.tar.gz -C src/${PLAT}_int64/
tar zxf ${ARCH}/${MUMPS}.tar.gz -C src/${PLAT}_int64/
tar zxf ${ARCH}/iphreeqc-3.7.3-15968.tar.gz -C src/
tar zxf ${ARCH}/${HYPRE}.tar.gz -C src/${PLAT}
tar zxf ${ARCH}/${MUMPS}.tar.gz -C src/${SEQ}_int64/
tar zxf ${ARCH}/${HYPRE}.tar.gz -C src/${SEQ}_int64/

cp src/conf/mpi/parmetis/* src/${PLAT}_int64/parmetis-4.0.3
cp src/conf/mpi/scotch/* src/${PLAT}_int64/${SCOTCH}/src
cp src/conf/mpi/hypre/* src/${PLAT}/${HYPRE}/src
cp src/conf/mpi/MUMPS/* src/${PLAT}_int64/${MUMPS}
cp src/conf/mt/hypre/* src/${SEQ}_int64/${HYPRE}/src
cp src/conf/mt/MUMPS/* src/${SEQ}_int64/${MUMPS}
cp src/conf/mt/iphreeqc/* src/iphreeqc-3.7.3-15968

cd ${HOME}/lib
cd src/${PLAT}_int64/parmetis-4.0.3
sh conf.bash

cd ${HOME}/lib
cd src/${PLAT}_int64/${SCOTCH}/src
sh conf.bash

cd ${HOME}/lib
cd src/iphreeqc-3.7.3-15968
sh conf.bash

cd ${HOME}/lib
cd src/${PLAT}/${HYPRE}/src
HYPRE=${HYPRE} sh conf.bash
make install

cd ${HOME}/lib
ln -sfT parmetis-4.0.3-${PLAT}_int64/ parmetis-${PLAT}_int64
ln -sfT src/${PLAT}_int64/${SCOTCH}/ scotch-${PLAT}_int64
ln -sfT iphreeqc-3.7.3/ iphreeqc
ln -sfT ${HYPRE}-${PLAT}/ hypre-${PLAT}

cd src/${PLAT}_int64/${MUMPS}
HOME=${HOME} make

cd ${HOME}/lib
ln -sfT src/${PLAT}_int64/${MUMPS}/ MUMPS-${PLAT}_int64

cd src/${SEQ}_int64/${HYPRE}/src
HYPRE=${HYPRE} sh conf.bash
make install

cd ${HOME}/lib
cd  src/${SEQ}_int64/${MUMPS}
HOME=${HOME} make

cd ${HOME}/lib
ln -sfT ${HYPRE}-${SEQ}/ hypre-${SEQ}
ln -sfT src/${SEQ}_int64/${MUMPS}/ MUMPS-${SEQ}_int64

