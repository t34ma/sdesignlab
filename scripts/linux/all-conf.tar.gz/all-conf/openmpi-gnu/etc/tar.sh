#!/bin/sh

SCOTCH=scotch-v7.0.3
HYPRE=hypre-2.28.0
MUMPS=MUMPS_5.6.0

ARCH=/home/ducom/mis/arch
tar zxf ${ARCH}/parmetis-4.0.3.tar.gz -C src/openmpi-gnu_int64/
tar zxf ${ARCH}/${SCOTCH}.tar.gz -C src/openmpi-gnu_int64/
tar zxf ${ARCH}/${MUMPS}.tar.gz -C src/openmpi-gnu_int64/
tar zxf ${ARCH}/iphreeqc-3.7.3-15968.tar.gz -C src/
tar zxf ${ARCH}/${HYPRE}.tar.gz -C src/openmpi-gnu
tar zxf ${ARCH}/${MUMPS}.tar.gz -C src/libseq-gnu_int64/
tar zxf ${ARCH}/${HYPRE}.tar.gz -C src/libseq-gnu_int64/
tar zxf ${ARCH}/${MUMPS}.tar.gz -C src/openmpi-gnu_ilp64/
tar zxf ${ARCH}/${HYPRE}.tar.gz -C src/openmpi-gnu_int64/
