#!/bin/sh

#HOME=${HOME}/DuCOM
HOME=${HOME}/work

PLAT=openmpi-gnu

ARCH=/home/ducom/mis/arch

HYPRE=hypre-2.28.0
MUMPS=MUMPS_5.6.0

cd ${HOME}/lib

cd src
mkdir ${PLAT}_ilp64/
cd ..

tar zxf ${ARCH}/${MUMPS}.tar.gz -C src/${PLAT}_ilp64/
tar zxf ${ARCH}/${HYPRE}.tar.gz -C src/${PLAT}_int64/

cp src/conf/mpi64/hypre/* src/${PLAT}_int64/${HYPRE}/src
cp src/conf/mpi64/MUMPS/* src/${PLAT}_ilp64/${MUMPS}

cd ${HOME}/lib
cd src/${PLAT}_int64/${HYPRE}/src
HYPRE=${HYPRE} sh conf.bash
make install

cd ${HOME}/lib
ln -sfT ${HYPRE}-${PLAT}_int64/ hypre-${PLAT}_int64

cd src/${PLAT}_ilp64/${MUMPS}
HOME=${HOME} make

cd ${HOME}/lib
ln -sfT src/${PLAT}_ilp64/${MUMPS}/ MUMPS-${PLAT}_ilp64

